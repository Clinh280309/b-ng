"""
SNAKE - Điều khiển bằng cử chỉ khuôn mặt qua webcam
Công nghệ: Python, OpenCV, MediaPipe, Pygame

Cách điều khiển:
- Di chuyển khuôn mặt sang trái/phải/lên/xuống so với tâm khung webcam để đổi hướng rắn.
- Nhấn R để chơi lại khi thua.
- Nhấn Q hoặc ESC để thoát.
"""

import sys
import random
import cv2
import mediapipe as mp
import pygame

# -------------------- Cấu hình --------------------
CELL = 20
COLS, ROWS = 30, 24
GAME_W, GAME_H = COLS * CELL, ROWS * CELL
CAM_W, CAM_H = 640, 480
FPS = 10

BG = (18, 24, 32)
SNAKE_COLOR = (70, 220, 120)
HEAD_COLOR = (130, 255, 170)
FOOD_COLOR = (255, 90, 100)
TEXT_COLOR = (245, 245, 245)
GRID_COLOR = (30, 38, 48)

# Ngưỡng để nhận biết khuôn mặt đã lệch khỏi tâm webcam.
# Tăng ngưỡng nếu rắn đổi hướng quá nhạy; giảm nếu khó điều khiển.
MOVE_THRESHOLD = 0.13


def random_food(snake):
    while True:
        pos = (random.randrange(COLS), random.randrange(ROWS))
        if pos not in snake:
            return pos


def main():
    pygame.init()
    screen = pygame.display.set_mode((GAME_W, GAME_H))
    pygame.display.set_caption("Snake - Dieu khien bang khuon mat")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 24, bold=True)
    small_font = pygame.font.SysFont("Arial", 16)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        pygame.quit()
        raise RuntimeError(
            "Khong mo duoc webcam. Hay kiem tra webcam va cap quyen truy cap cho ung dung."
        )
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_H)

    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    snake = [(COLS // 2, ROWS // 2), (COLS // 2 - 1, ROWS // 2), (COLS // 2 - 2, ROWS // 2)]
    direction = (1, 0)
    next_direction = direction
    food = random_food(snake)
    score = 0
    game_over = False
    face_status = "Dang tim khuon mat..."

    try:
        running = True
        while running:
            # Đọc webcam và nhận diện khuôn mặt
            ok, frame = cap.read()
            face_center = None
            if ok:
                frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = face_mesh.process(rgb)

                if results.multi_face_landmarks:
                    landmarks = results.multi_face_landmarks[0].landmark
                    # Chóp mũi (1) làm điểm điều khiển.
                    nose = landmarks[1]
                    nx, ny = nose.x, nose.y
                    face_center = (nx, ny)
                    face_status = f"Vi tri khuon mat: x={nx:.2f}, y={ny:.2f}"

                    dx, dy = nx - 0.5, ny - 0.5
                    # Chọn trục lệch nhiều hơn để điều khiển rõ ràng.
                    if max(abs(dx), abs(dy)) >= MOVE_THRESHOLD:
                        if abs(dx) > abs(dy):
                            candidate = (1, 0) if dx > 0 else (-1, 0)
                        else:
                            candidate = (0, 1) if dy > 0 else (0, -1)

                        # Không cho rắn quay ngược trực tiếp vào thân.
                        if candidate != (-direction[0], -direction[1]):
                            next_direction = candidate
                else:
                    face_status = "Chua thay khuon mat - hay ngoi truoc webcam"

                # Hiển thị khung webcam, tâm và điểm mũi
                h, w = frame.shape[:2]
                cv2.line(frame, (w // 2, 0), (w // 2, h), (80, 180, 255), 1)
                cv2.line(frame, (0, h // 2), (w, h // 2), (80, 180, 255), 1)
                if face_center:
                    px, py = int(face_center[0] * w), int(face_center[1] * h)
                    cv2.circle(frame, (px, py), 8, (0, 255, 0), -1)
                cv2.putText(frame, "Move your face to steer", (12, 28),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)
                cv2.imshow("Webcam - Dieu khien Snake (nhan Q de dong)", frame)
            else:
                face_status = "Khong doc duoc webcam"

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_q, pygame.K_ESCAPE):
                        running = False
                    elif event.key == pygame.K_r and game_over:
                        snake = [(COLS // 2, ROWS // 2),
                                 (COLS // 2 - 1, ROWS // 2),
                                 (COLS // 2 - 2, ROWS // 2)]
                        direction = (1, 0)
                        next_direction = direction
                        food = random_food(snake)
                        score = 0
                        game_over = False

            if not game_over:
                direction = next_direction
                hx, hy = snake[0]
                new_head = (hx + direction[0], hy + direction[1])

                # Va tường hoặc đâm vào thân
                if (new_head[0] < 0 or new_head[0] >= COLS or
                    new_head[1] < 0 or new_head[1] >= ROWS or
                    new_head in snake[:-1]):
                    game_over = True
                else:
                    snake.insert(0, new_head)
                    if new_head == food:
                        score += 1
                        food = random_food(snake)
                    else:
                        snake.pop()

            screen.fill(BG)
            # Lưới nhẹ giúp dễ nhìn ô di chuyển
            for x in range(0, GAME_W, CELL):
                pygame.draw.line(screen, GRID_COLOR, (x, 0), (x, GAME_H))
            for y in range(0, GAME_H, CELL):
                pygame.draw.line(screen, GRID_COLOR, (0, y), (GAME_W, y))

            fx, fy = food
            pygame.draw.rect(screen, FOOD_COLOR,
                             (fx * CELL + 2, fy * CELL + 2, CELL - 4, CELL - 4),
                             border_radius=6)
            for i, (sx, sy) in enumerate(snake):
                color = HEAD_COLOR if i == 0 else SNAKE_COLOR
                pygame.draw.rect(screen, color,
                                 (sx * CELL + 1, sy * CELL + 1, CELL - 2, CELL - 2),
                                 border_radius=5)

            score_surface = font.render(f"Diem: {score}", True, TEXT_COLOR)
            screen.blit(score_surface, (10, 8))
            help_surface = small_font.render("Di chuyen mat | Q/ESC: thoat", True, TEXT_COLOR)
            screen.blit(help_surface, (10, GAME_H - 24))

            if game_over:
                overlay = pygame.Surface((GAME_W, GAME_H), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 175))
                screen.blit(overlay, (0, 0))
                title = font.render("GAME OVER", True, (255, 120, 120))
                retry = small_font.render("Nhan R de choi lai | Q de thoat", True, TEXT_COLOR)
                screen.blit(title, title.get_rect(center=(GAME_W // 2, GAME_H // 2 - 18)))
                screen.blit(retry, retry.get_rect(center=(GAME_W // 2, GAME_H // 2 + 18)))

            pygame.display.flip()
            clock.tick(FPS)

            # Q đóng cả cửa sổ webcam và game
            if cv2.waitKey(1) & 0xFF == ord('q'):
                running = False

    finally:
        cap.release()
        face_mesh.close()
        cv2.destroyAllWindows()
        pygame.quit()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\nLoi: {exc}")
        print("Hay cai dat thu vien theo README.md va kiem tra webcam.")
        sys.exit(1)
