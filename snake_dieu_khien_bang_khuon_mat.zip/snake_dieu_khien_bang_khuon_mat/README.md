# Snake điều khiển bằng khuôn mặt

Phần mềm trò chơi Snake (rắn săn mồi) điều khiển hướng đi bằng cách di chuyển khuôn mặt trước webcam.

## 1. Yêu cầu
- Máy tính Windows 10/11 hoặc máy có Python 3.10/3.11.
- Webcam hoạt động.
- Kết nối Internet lần đầu để cài thư viện.

## 2. Cài đặt
1. Cài Python từ https://www.python.org/downloads/ . Khi cài, tích chọn **Add Python to PATH**.
2. Giải nén thư mục dự án.
3. Mở thư mục `snake_dieu_khien_bang_khuon_mat`.
4. Bấm vào thanh địa chỉ của File Explorer, gõ `cmd` rồi nhấn Enter.
5. Gõ lệnh sau và nhấn Enter:

   ```bash
   python -m pip install -r requirements.txt
   ```

## 3. Chạy trò chơi
Trong cửa sổ CMD, gõ:

```bash
python snake_face_control.py
```

Một cửa sổ trò chơi và một cửa sổ webcam sẽ xuất hiện.

## 4. Cách chơi
- Di chuyển khuôn mặt sang trái, phải, lên hoặc xuống so với tâm khung webcam để điều khiển rắn.
- Ăn ô thức ăn màu đỏ để tăng điểm.
- Khi thua, nhấn **R** để chơi lại.
- Nhấn **Q** hoặc **Esc** để thoát.

## 5. Nếu gặp lỗi
- Nếu không mở được webcam, đóng các ứng dụng đang dùng webcam và kiểm tra quyền Camera trong Windows Settings.
- Nếu lệnh `python` không chạy, thử `py -m pip install -r requirements.txt` và `py snake_face_control.py`.
- Nếu điều khiển quá nhạy hoặc quá chậm, mở `snake_face_control.py` và thay đổi `MOVE_THRESHOLD = 0.13`. Tăng giá trị để giảm độ nhạy; giảm giá trị để tăng độ nhạy.
- Cửa sổ webcam cần được giữ mở trong lúc chơi.

## Công nghệ
Python, OpenCV, MediaPipe Face Mesh, Pygame.
